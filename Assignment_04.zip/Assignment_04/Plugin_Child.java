public class Plugin_Child extends Plugin {
	

}
