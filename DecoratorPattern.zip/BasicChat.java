import java.lang.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;

public class BasicChat implements Chat {

	@Override
	public void Assemble() {
		System.out.println("Basic chat!");
	}

}
