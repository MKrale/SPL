public interface Chat {
	
	public void Assemble();

}
